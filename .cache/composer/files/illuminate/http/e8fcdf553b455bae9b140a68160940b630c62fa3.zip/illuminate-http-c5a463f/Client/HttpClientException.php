<?php

namespace Illuminate\Http\Client;

use Exception;

class HttpClientException extends Exception
{
    //
}
